<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up | Sulit & Bagasan Dental Office</title>
    <link rel="stylesheet" type="text/css" href="style_OTP.css">
    <style>
        <?php include '../header-footer/header-footer.css' ?>
    </style>

</head>

<body>

    <?php include '../header-footer/header.php' ?>

    <div class="wrapper">
        <div class="form">

                <h1 class="title">SIGN UP</h1>
                <hr>

        

                <p class="email-label">Signup successful. <br>
       Please check your email to activate your account.</p>


                </div>
            </form>
        </div>

    </div>

    <?php include '../header-footer/footer.php' ?>


</body>

</html>